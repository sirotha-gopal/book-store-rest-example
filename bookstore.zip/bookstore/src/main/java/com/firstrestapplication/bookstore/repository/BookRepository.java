package com.firstrestapplication.bookstore.repository;

import org.springframework.data.repository.CrudRepository;

import com.firstrestapplication.bookstore.entites.Book;

public interface BookRepository extends CrudRepository<Book,Long>{

	Book findByAuthor(String author);

}
