package com.firstrestapplication.bookstore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.firstrestapplication.bookstore.entites.Book;
import com.firstrestapplication.bookstore.repository.BookRepository;

@Service
public class BookService {
	
	@Autowired
	BookRepository bookRepo;
	
	public List<Book> getAllBooks(){
		System.out.println("BookRepository Object::"+bookRepo);
		List<Book> books = new ArrayList<Book>();
		bookRepo.findAll().forEach(book1->books.add(book1));
		return books;
		
	}

	public Optional<Book> getBookById(Long id) {
		// TODO Auto-generated method stub
		return bookRepo.findById(id);
	}

	public void save(Book book) {
		// TODO Auto-generated method stub
		bookRepo.save(book);
		
	}
	public void deleteAll() {
		bookRepo.deleteAll();
		
	}

	public void saveAll(List<Book> books) {
		// TODO Auto-generated method stub
		bookRepo.saveAll(books);
	}

	public Book getBookByAuthor(String author) {
		// TODO Auto-generated method stub
		return bookRepo.findByAuthor(author);

	}
	
	
}
