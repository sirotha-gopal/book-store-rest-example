package com.firstrestapplication.bookstore.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.firstrestapplication.bookstore.entites.Book;
import com.firstrestapplication.bookstore.service.BookService;

@RestController
@RequestMapping("/book-store")
public class BookController {
	
	@Autowired
	BookService bookService;
	
	/*Getting All Books*/
	@GetMapping("/books")
	public List<Book> getAllBooks(){
		return bookService.getAllBooks();
	}
	
	/*Getting a book by id*/
	@GetMapping("/books/{id}")
	public Optional<Book> getBook(@PathVariable Long id){
		return bookService.getBookById(id);
	}
	
	/*Getting Book by author*/
	@GetMapping("/books/author/{author}")
	public Book getBookByAuthor(@PathVariable String author){
		return bookService.getBookByAuthor(author);
	}
	
	
	
	/*Save a Book*/
	@PostMapping("/books/book")
	public Long saveOrUpdate(@RequestBody Book book) {
		bookService.save(book);
		
		return book.getId();
	}
	
	/*Saving All Books*/
	@PostMapping("/books")
	public List<Long> saveAll(@RequestBody List<Book> books) {
		
		bookService.saveAll(books);
		List<Long> ids = new ArrayList<Long>();
		for(Book b : books) {
			ids.add(b.getId());
		}
		return ids;
	}
	
	
	/*Updating the Book*/
	@PutMapping("/books")
	public String updateOrSave(@RequestBody Book book) {
		
		bookService.save(book);
		
		return "Book with id "+book.getId()+" is updated";
		
	}
	
	/*Partially Updating Book*/
	@PatchMapping("/books/{id}")
	public String updatePartial(@RequestBody Map<String,String> update, @PathVariable Long id) {
		Book book = bookService.getBookById(id).get();
		
		if(!update.isEmpty()) {
			
			for (String str : update.keySet()) {
				if(str.equals("author"))
					book.setAuthor(update.get(str));
				else if(str.equals("name"))
					book.setName(update.get(str));
				else if(str.equals("price"))
					book.setPrice(new BigDecimal(update.get(str)));
			}
			bookService.save(book);
		}else {
			return "Somthing Went Wrong";
		}
		
		
		return "Book Updated";
	}
	
	/*Delete all Book*/
	@DeleteMapping("/books")
	public String deleteAll() {
		bookService.deleteAll();
		return "deleted all records";
	}
	
	
}
